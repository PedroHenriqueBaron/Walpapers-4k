<template>
  <div class="container">

<head>
    <title> Walpapers 4k </title>
    <link rel="stylesheet" href="css/index.css">
</head>

<body>
    <div class="titulo">
        <h1>Walpapers 4k</h1>
        <h2>Pedro Baron</h2>
    </div>
    <div class="imagem1">
        <img src="@/assets/cachorros-engracados.jpg" height="17%" width="100%" />
    </div>
        <br>
        <div class="imagem2">
        <img src="@/assets/mulherpeixe.jpg" height="37%" width="64%" />
        <img src="@/assets/9d5a18e7ffc7e7afba8d609d6e21f5c089772175_00.jpg" height="37%" width="35%" />
    </div>
    <div class="video">
    <video width="100%" height="7%" controls>
        <source src="@/assets/CINCO PATINHOS SOUTH AMERICA MEMES.mp4">
        </video>
    </div>
</body>


  </div>
</template>
  
<script>
export default {
  name: 'HelloWorld',
};


</script>
  
<style scoped>
@media screen and (min-width: 1200px){
    /*Desktop*/
    .imagem2 {
        text-align: left;
         
    }
    
}
@media screen and (min-width: 601px) and (max-width: 1199px){
    /*Tablet*/
    .imagem2 {
        text-align: left;
         
    }
    }
@media screen and (max-width: 600px){
    /*Celular*/
    .imagem2 {
        text-align: center;
        width: 100%;
        
    }

    

}
/* 
.titulo{
    text-align: center;
}
.video{
    text-align: center;
} */
.container {
  text-align: center;
  margin-top: 50px;
}


</style>